#include <stdlib.h>
#include <sys/syscall.h>
#include <string.h>

/* here is where there is games
   with strings where the data in
   data out flows the right way */

int module(int);

int
main(int argc, char *argv[]){
	if (argc != 2)
		exit(1);

	if( (strcmp(argv[1], "one")) == 0) 
		module(0);
	else if( (strcmp(argv[1], "two")) == 0)
		module(1);
	else if( (strcmp(argv[1], "three")) == 0)
		module(2);
	return 0;
}
