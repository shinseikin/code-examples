#include <sys/syscall.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

extern int
module(int str){
	int filedscr;

	if ( (filedscr = 
		open("/dev/stdout", O_WRONLY, NULL)) < 0) {		printf(" file descr open failed");
		return 250;
	}

	switch(str){
		case 0:
			write(filedscr, "kousan suru\n",13);
			break;
		case 1:
			write(filedscr, "hayai desu.\n", 13);
			break;
		case 2:
			write(filedscr, "hai kansetsu.\n", 15);
			break;
		default:
			write(filedscr, "try again\n", 11);
			break;
	}
	close(filedscr);
	return 0;
}
